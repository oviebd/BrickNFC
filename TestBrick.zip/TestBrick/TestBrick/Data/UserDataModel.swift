//
//  UserDataModel.swift
//  TestBrick
//
//  Created by Habibur Rahman on 1/5/25.
//

import Foundation

struct UserProfileData : Codable {
    let email: String
}
